# 3D simulation data generation

Please run `gen_data.m` to generate 3d simulation data, including groundtruth poses and landmarks, observations and odometry information.

`config.m` allows you to change the number of landmarks, noise level and etc.
